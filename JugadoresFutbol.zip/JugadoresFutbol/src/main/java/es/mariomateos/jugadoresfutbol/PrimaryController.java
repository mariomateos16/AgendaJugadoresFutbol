package es.mariomateos.jugadoresfutbol;

import es.mariomateos.jugadoresfutbol.entities.Futbolista;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TablePosition;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javax.persistence.Query;

public class PrimaryController implements Initializable {

    private Futbolista futbolistaSeleccionado;
    @FXML
    private TableView<Futbolista> tableViewFutbolistas;
    @FXML
    private TableColumn<Futbolista, String> columnaNombre;
    @FXML
    private TableColumn<Futbolista, String> columnaApellidos;
    @FXML
    private TableColumn<Futbolista, String> columnaEquipo;
    @FXML
    private TextField textFieldNombre;
    @FXML
    private TextField textFieldApellidos;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        //        System.out.print("entrando initialize");
//        System.out.println("adfhj");
        columnaNombre.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        columnaApellidos.setCellValueFactory(new PropertyValueFactory<>("apellidos"));
        columnaEquipo.setCellValueFactory(
                cellData -> {
                    SimpleStringProperty property = new SimpleStringProperty();
                    if (cellData.getValue().getEquipo()!= null){
                        String nombreFut = cellData.getValue().getEquipo().getNombre();
                        property.setValue(nombreFut);
                    }
                    return property;
                });
        tableViewFutbolistas.getSelectionModel().selectedItemProperty().addListener(
                (observable, oldValue, newValue) -> {
                    futbolistaSeleccionado = newValue;
                    if (futbolistaSeleccionado != null){
                        textFieldNombre.setText(futbolistaSeleccionado.getNombre());
                        textFieldApellidos.setText(futbolistaSeleccionado.getApellidos());
                    }else {
                        textFieldNombre.setText("");
                        textFieldApellidos.setText("");
                    }
                });
            cargarTodosFutbolistas();
    }    
    
    private void cargarTodosFutbolistas(){
        System.out.println("Se han cargado todos los futbolistas, cargarTodosFutbolistas()");
        Query queryFutbolistaFindAll = App.em.createNamedQuery("Futbolista.findAll");
        List<Futbolista> listFutbolista = queryFutbolistaFindAll.getResultList();
        tableViewFutbolistas.setItems(FXCollections.observableArrayList(listFutbolista));
    }
    
    @FXML
    private void onActionButtonGuardar(ActionEvent event) {
        if (futbolistaSeleccionado != null){
            futbolistaSeleccionado.setNombre(textFieldNombre.getText());
            futbolistaSeleccionado.setApellidos(textFieldApellidos.getText());
            App.em.getTransaction().begin();
            App.em.merge(futbolistaSeleccionado);
            App.em.getTransaction().commit();
            
            int numFilaSeleccionada = tableViewFutbolistas.getSelectionModel().getSelectedIndex();
            tableViewFutbolistas.getItems().set(numFilaSeleccionada, futbolistaSeleccionado);
            TablePosition pos = new TablePosition(tableViewFutbolistas, numFilaSeleccionada, null);
            tableViewFutbolistas.getFocusModel().focus(pos);
            tableViewFutbolistas.requestFocus();
        }
        
    }    
    
    @FXML
    private void onActionButtonSuprimir(ActionEvent event) {
        if(futbolistaSeleccionado != null){ 
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Confirmar");
            alert.setHeaderText("¿Desea suprimir el siguiente registro?");
            alert.setContentText(futbolistaSeleccionado.getNombre() + " " + futbolistaSeleccionado.getApellidos());
            Optional<ButtonType> result = alert.showAndWait();
            if(result.get() == ButtonType.OK){
                App.em.getTransaction().begin();
                App.em.merge(futbolistaSeleccionado);
                App.em.getTransaction().commit();
                tableViewFutbolistas.getItems().remove(futbolistaSeleccionado);
                tableViewFutbolistas.getFocusModel().focus(null);
                tableViewFutbolistas.requestFocus();
            } else{
                int numFilaSeleccionada = tableViewFutbolistas.getSelectionModel().getSelectedIndex();
                tableViewFutbolistas.getItems().set(numFilaSeleccionada, futbolistaSeleccionado);
                TablePosition pos = new TablePosition(tableViewFutbolistas, numFilaSeleccionada, null);
                tableViewFutbolistas.getFocusModel().focus(pos);
                tableViewFutbolistas.requestFocus();
            }
        } else{
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Atención");
            alert.setHeaderText("Debe Seleccionarun registro");
            alert.showAndWait();
        }
    }
    
    @FXML
    private void onActionButtonNuevo(ActionEvent event) {
        try {
            App.setRoot("secondary");
            SecondaryController secondaryController = (SecondaryController)App.fxmlLoader.getController();
            futbolistaSeleccionado = new Futbolista();
            secondaryController.setFutbolista(futbolistaSeleccionado, true);
        }catch (IOException ex) {
            Logger.getLogger(PrimaryController.class.getName()).log(Level.SEVERE, ex.getMessage(), ex);
        }
    }
    
    @FXML
    private void onActionButtonEditar(ActionEvent event) {
        if(futbolistaSeleccionado != null) {
            try {
                App.setRoot("secondary");
                SecondaryController secondaryController = (SecondaryController)App.fxmlLoader.getController();
                secondaryController.setFutbolista(futbolistaSeleccionado, false);
            }catch (IOException ex) {
                Logger.getLogger(PrimaryController.class.getName()).log(Level.SEVERE, ex.getMessage(), ex);
            }
        } else {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Atención");
            alert.setHeaderText("Debe seleccionar un futbolista");
            alert.showAndWait();
        }
    }
    
    private void switchToSecondary() throws IOException {
        App.setRoot("secondary");
    }
}
