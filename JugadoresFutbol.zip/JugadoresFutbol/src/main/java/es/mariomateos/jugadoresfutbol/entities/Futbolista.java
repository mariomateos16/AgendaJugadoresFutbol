/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.mariomateos.jugadoresfutbol.entities;

import es.mariomateos.jugadoresfutbol.entities.Equipo;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author msi
 */
@Entity
@Table(name = "FUTBOLISTA")
@NamedQueries({
    @NamedQuery(name = "Futbolista.findAll", query = "SELECT f FROM Futbolista f"),
    @NamedQuery(name = "Futbolista.findById", query = "SELECT f FROM Futbolista f WHERE f.id = :id"),
    @NamedQuery(name = "Futbolista.findByNombre", query = "SELECT f FROM Futbolista f WHERE f.nombre = :nombre"),
    @NamedQuery(name = "Futbolista.findByApellidos", query = "SELECT f FROM Futbolista f WHERE f.apellidos = :apellidos"),
    @NamedQuery(name = "Futbolista.findByNacionalidad", query = "SELECT f FROM Futbolista f WHERE f.nacionalidad = :nacionalidad"),
    @NamedQuery(name = "Futbolista.findByGoles", query = "SELECT f FROM Futbolista f WHERE f.goles = :goles"),
    @NamedQuery(name = "Futbolista.findByAsistencias", query = "SELECT f FROM Futbolista f WHERE f.asistencias = :asistencias"),
    @NamedQuery(name = "Futbolista.findByTarjetasAmarillas", query = "SELECT f FROM Futbolista f WHERE f.tarjetasAmarillas = :tarjetasAmarillas"),
    @NamedQuery(name = "Futbolista.findByTarjetasRojas", query = "SELECT f FROM Futbolista f WHERE f.tarjetasRojas = :tarjetasRojas"),
    @NamedQuery(name = "Futbolista.findByFechaNacimiento", query = "SELECT f FROM Futbolista f WHERE f.fechaNacimiento = :fechaNacimiento"),
    @NamedQuery(name = "Futbolista.findBySalario", query = "SELECT f FROM Futbolista f WHERE f.salario = :salario"),
    @NamedQuery(name = "Futbolista.findByFoto", query = "SELECT f FROM Futbolista f WHERE f.foto = :foto")})
public class Futbolista implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "ID")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "NOMBRE")
    private String nombre;
    @Basic(optional = false)
    @Column(name = "APELLIDOS")
    private String apellidos;
    @Column(name = "NACIONALIDAD")
    private String nacionalidad;
    @Column(name = "GOLES")
    private String goles;
    @Column(name = "ASISTENCIAS")
    private String asistencias;
    @Column(name = "TARJETAS_AMARILLAS")
    private String tarjetasAmarillas;
    @Column(name = "TARJETAS_ROJAS")
    private String tarjetasRojas;
    @Column(name = "FECHA_NACIMIENTO")
    @Temporal(TemporalType.DATE)
    private Date fechaNacimiento;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "SALARIO")
    private BigDecimal salario;
    @Column(name = "FOTO")
    private String foto;
    @JoinColumn(name = "EQUIPO", referencedColumnName = "ID")
    @ManyToOne
    private Equipo equipo;

    public Futbolista() {
    }

    public Futbolista(Integer id) {
        this.id = id;
    }

    public Futbolista(Integer id, String nombre, String apellidos) {
        this.id = id;
        this.nombre = nombre;
        this.apellidos = apellidos;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getNacionalidad() {
        return nacionalidad;
    }

    public void setNacionalidad(String nacionalidad) {
        this.nacionalidad = nacionalidad;
    }

    public String getGoles() {
        return goles;
    }

    public void setGoles(String goles) {
        this.goles = goles;
    }

    public String getAsistencias() {
        return asistencias;
    }

    public void setAsistencias(String asistencias) {
        this.asistencias = asistencias;
    }

    public String getTarjetasAmarillas() {
        return tarjetasAmarillas;
    }

    public void setTarjetasAmarillas(String tarjetasAmarillas) {
        this.tarjetasAmarillas = tarjetasAmarillas;
    }

    public String getTarjetasRojas() {
        return tarjetasRojas;
    }

    public void setTarjetasRojas(String tarjetasRojas) {
        this.tarjetasRojas = tarjetasRojas;
    }

    public Date getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(Date fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public BigDecimal getSalario() {
        return salario;
    }

    public void setSalario(BigDecimal salario) {
        this.salario = salario;
    }

    public String getFoto() {
        return foto;
    }

    public void setFoto(String foto) {
        this.foto = foto;
    }

    public Equipo getEquipo() {
        return equipo;
    }

    public void setEquipo(Equipo equipo) {
        this.equipo = equipo;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Futbolista)) {
            return false;
        }
        Futbolista other = (Futbolista) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "es.mariomateos.jugadoresfutbol.entities.Futbolista[ id=" + id + " ]";
    }
    
}
